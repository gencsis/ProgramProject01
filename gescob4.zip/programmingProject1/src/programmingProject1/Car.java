package programmingProject1;

/**
 * Represents a car object with make, year, and price.
 * 
 * CSC 1351 Programming Project No. 01
 * Section 2
 * 
 * @author <Genesis Escobar>
 * @since <03.17.2024>
 */
public class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;
    
    // Constructor to initialize Car object
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    
    // Getter method for make
    public String getMake() {
        return make;
    }
    
    // Getter method for year
    public int getYear() {
        return year;
    }
    
    // Getter method for price
    public int getPrice() {
        return price;
    }
    
    // Compare cars based on year and price
    @Override
    public int compareTo(Car otherCar) {
        if (this.year != otherCar.year)
            return this.year - otherCar.year;
        else
            return this.price - otherCar.price;
    }
    
    // String representation of Car object
    @Override
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price;
    }
}