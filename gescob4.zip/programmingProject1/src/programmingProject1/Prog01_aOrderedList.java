package programmingProject1;

import java.io.*;
import java.util.Scanner;

/**
* This program manages a list of cars. It reads car information from an input file,
* adds or deletes cars based on the input, and writes the updated list to an output file.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author <Genesis Escobar>
* @since <03.17.2024>
*/
public class Prog01_aOrderedList {
    
    /**
    * Main method to execute the program.
    *
    * CSC 1351 Programming Project No 1
    * Section 2
    *
    * @param args Command line arguments
    * @throws FileNotFoundException if input/output files are not found
    */
    public static void main(String[] args) {
        Prog01_aOrderedList program = new Prog01_aOrderedList();
        aOrderedList orderedList = new aOrderedList();

        try {
            Scanner inputScanner = program.getInputFile("Enter input filename: ");
            System.out.println("Scanner for input file created successfully.");

            // Process each line of the input file
            while (inputScanner.hasNextLine()) {
                String line = inputScanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length == 4 && parts[0].equals("A")) {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = Integer.parseInt(parts[3]);
                    Car car = new Car(make, year, price);
                    orderedList.add(car);
                } else if (parts.length == 3 && parts[0].equals("D")) {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    orderedList.delete(make, year);
                }
            }
            inputScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Program execution terminated.");
            return;
        }
        
        // Write updated list to output file
        try {
            PrintWriter outputWriter = program.getOutputFile("Enter output filename: ");
            System.out.println("Output file created successfully.");

            // Write number of cars
            outputWriter.printf("%-10s %10s\n\n", "Number of cars:", orderedList.size());
            // Write car details
            for (int i = 0; i < orderedList.size(); i++) {
                Car car = (Car) orderedList.get(i);
                outputWriter.printf("%-10s %10s\n", "Make:", car.getMake());
                outputWriter.printf("%-10s %10s\n", "Year:", car.getYear());
                outputWriter.printf("%-10s %10s\n", "Price:", "$" + String.format("%,d", car.getPrice()));
                if (i < orderedList.size() - 1) {
                    outputWriter.println(); 
                }
            }
            outputWriter.close();
        } catch (FileNotFoundException e){
            System.out.println("Program cancelled.");
        }
    }
    
    /**
    * Reads input file specified by the user.
    *
    * @param userPrompt Prompt message to ask for input file name
    * @return Scanner object for the input file
    * @throws FileNotFoundException if input file is not found
    */
    public Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        String fileName;
        Scanner in = new Scanner(System.in);
        Scanner fileScanner = null;
        
        while (fileScanner == null) {
            System.out.println(userPrompt);
            fileName = in.nextLine();
            try {
                fileScanner = new Scanner(new File(fileName));
            } catch (FileNotFoundException e) {
                System.out.println("File specified <" + fileName + "> does not exist or cannot be created. Would you like to continue? <Y/N>");
                while(true) {
                    String userResponse = in.nextLine();
                    if (userResponse.equalsIgnoreCase("N")) {
                        throw new FileNotFoundException();
                    } else if (userResponse.equalsIgnoreCase("Y")) {
                        break;
                    } else {
                        System.out.println("Please enter <Y> or <N>.");
                    }
                }
            }
        }
        return fileScanner;
    }
    
    /**
    * Creates output file specified by the user.
    *
    * @param userPrompt Prompt message to ask for output file name
    * @return PrintWriter object for the output file
    * @throws FileNotFoundException if output file is not found
    */
    public PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        String fileName;
        Scanner in = new Scanner(System.in);
        PrintWriter printWriter = null;
        
        while (printWriter == null) {
            System.out.println(userPrompt);
            fileName = in.nextLine();
            try {
                printWriter = new PrintWriter(new File(fileName));
            } catch (FileNotFoundException e) {
                while(true) {
                    System.out.println("File specified <" + fileName + "> does not exist or cannot be created. Would you like to continue? <Y/N>");
                    String userResponse = in.nextLine();
                    if (userResponse.equalsIgnoreCase("N")) {
                        throw new FileNotFoundException();
                    } else if (userResponse.equalsIgnoreCase("Y")) {
                        break;
                    } else {
                        System.out.println("Please enter <Y> or <N>.");
                    }
                }
            }
        }
        in.close();
        return printWriter;
    }
}