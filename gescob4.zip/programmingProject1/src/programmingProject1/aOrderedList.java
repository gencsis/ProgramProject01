package programmingProject1;

import java.util.Arrays;

/**
 * Represents an ordered list of cars.
 *
 * CSC 1351 Programming Project No 1
 * Section 2
 *
 * @author <Genesis Escobar>
 * @since <03.17.2024>
 */
public class aOrderedList {
    final int SIZE_INCREMENTS = 20;
    private Car[] oList; // Array to store cars
    private int listSize; // Total capacity of the list
    private int numObjects; // Number of cars in the list
    private int curr; // Index of current element accessed via iterator methods

    /**
     * Constructs an empty ordered list with default size increments.
     */
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZE_INCREMENTS;
        oList = new Car[SIZE_INCREMENTS];
        curr = 0;
    }

    /**
     * Adds a new car to the list.
     * If the list is full, it expands the list capacity.
     *
     * @param newCar The car to add
     */
    public void add(Car newCar) {
        if (numObjects >= oList.length) {
            oList = Arrays.copyOf(oList, oList.length + SIZE_INCREMENTS);
        }
        oList[numObjects] = newCar;
        numObjects++;
        sortList(); // Sort the list after adding
    }

    /**
     * Retrieves the car at the specified index.
     *
     * @param index The index of the car to retrieve
     * @return The car at the specified index
     */
    public Car get(int index) {
        return oList[index];
    }

    /**
     * Returns the number of cars in the list.
     *
     * @return The number of cars in the list
     */
    public int size() {
        return numObjects;
    }

    /**
     * Resets the current position for iterator methods.
     */
    public void reset() {
        curr = 0;
    }

    /**
     * Retrieves the next car in the list.
     *
     * @return The next car in the list
     */
    public Car next() {
        return oList[curr++];
    }

    /**
     * Checks if there is another car in the list.
     *
     * @return true if there is another car, false otherwise
     */
    public boolean hasNext() {
        return curr < numObjects;
    }

    /**
     * Removes the car at the specified index from the list.
     *
     * @param index The index of the car to remove
     */
    public void remove(int index) {
        if (index >= 0 && index < numObjects) {
            for (int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            oList[numObjects - 1] = null;
            numObjects--;
        }
    }

    /**
     * Sorts the list of cars based on natural ordering.
     */
    private void sortList() {
        Arrays.sort(oList, 0, numObjects);
    }

    /**
     * Deletes a car with the specified make and year from the list.
     *
     * @param make The make of the car to delete
     * @param year The year of the car to delete
     */
    public void delete(String make, int year) {
        for (int i = 0; i < numObjects; i++) {
            Car car = oList[i];
            if (car.getMake().equalsIgnoreCase(make) && car.getYear() == year) {
                remove(i);
                break; // Exit loop after deleting the first occurrence
            }
        }
    }
}